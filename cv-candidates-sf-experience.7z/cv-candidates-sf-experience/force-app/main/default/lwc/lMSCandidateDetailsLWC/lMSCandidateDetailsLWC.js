import { LightningElement, wire, track, api } from 'lwc';
import Current_Candidate from '@salesforce/label/c.Current_Candidate';
import Candidate_Score from '@salesforce/label/c.Candidate_Score';
import CandidateDetails from '@salesforce/messageChannel/CandidateDetails__c'; 
import { subscribe,MessageContext} from 'lightning/messageService';
export default class LMSCandidateDetailsLWC extends LightningElement {
  @wire(MessageContext)
  context;
  name;
  score;
  Current_Candidate = Current_Candidate;
  Candidate_Score = Candidate_Score;
  connectedCallback() {
     console.log('we are in child LWC..');
     this.subscribeMessage();
     console.log(this.name);
     console.log(this.score);
  }
  subscribeMessage() {
     console.log('subscribeMessage  calling...');
     subscribe(this.context, CandidateDetails, (message) => {
        this.handleMessage(message)
     });
  }
  handleMessage(message) {
     console.log('handleMessage calling on CandidateDetails....', message);
     this.name = message.name;
     this.score = message.score;
  }
}