import { LightningElement } from 'lwc';
export default class LMSMainLWC extends LightningElement {
    getCandidateList(){
        console.log('get candidate details');
        this.template.querySelector('c-l-m-s-candidate-list-l-w-c').LoadCandidates();
    }
}