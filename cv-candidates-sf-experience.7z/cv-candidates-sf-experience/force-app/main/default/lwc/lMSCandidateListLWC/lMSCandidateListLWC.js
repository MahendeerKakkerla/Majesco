import { LightningElement, wire, track, api } from 'lwc';
import getCandidateList from '@salesforce/apex/CandidateController.getCandidateList';
import Candidate_Name from '@salesforce/label/c.Candidate_Name';
import Candidate_Score from '@salesforce/label/c.Candidate_Score';
import CandidateDetails from '@salesforce/messageChannel/CandidateDetails__c'; 
import { publish, MessageContext} from 'lightning/messageService';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class LMSCandidateListLWC extends LightningElement {
  @wire(MessageContext)
  messageContext;
  @track candidateList;
  Candidate_Name = Candidate_Name;
  Candidate_Score = Candidate_Score;
  name;
  score;
  @api
  LoadCandidates() {
     getCandidateList()
        .then(data => {
           console.log('====getCandidateList=', data);
           if (!(this.isEmpty(data))) {
              console.log('getCandidateList is not empty --');
              this.candidateList = data;
           } else {
              console.log('getCandidateList is empty or not defined---');
              const event = new ShowToastEvent({
                 title: 'Error!',
                 message: 'No Data Present In System',
                 variant: 'error',
                 mode: 'dismissable'
              });
              this.dispatchEvent(event);
              return;
           }
        }).catch(error => {
           console.log('error---' + error);
           const event = new ShowToastEvent({
              title: 'Error!',
              message: 'Sorry! Internal Error Occured.',
              variant: 'error',
              mode: 'dismissable'
           });
           this.dispatchEvent(event);
           return;
        });
  }
  isEmpty(val) {
     return (val === undefined || val == null || val.length <= 0) ? true : false;
  }
  callChildLWC(event) {
     console.log('callChildMethodd---');
     this.name = event.currentTarget.dataset.id;
     this.score = event.currentTarget.dataset.label;
     console.log('name---', this.name);
     console.log('score---', this.score);
     // publisher using Lightning Message Service
     let msg = {
        name: this.name,
        score: this.score
     };
     publish(this.messageContext, CandidateDetails, msg);
  }
}