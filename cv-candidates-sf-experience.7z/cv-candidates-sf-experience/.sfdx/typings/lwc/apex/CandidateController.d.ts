declare module "@salesforce/apex/CandidateController.getCandidateList" {
  export default function getCandidateList(): Promise<any>;
}
