declare module "@salesforce/messageChannel/CandidateDetails__c" {
    var CandidateDetails: string;
    export default CandidateDetails;
}