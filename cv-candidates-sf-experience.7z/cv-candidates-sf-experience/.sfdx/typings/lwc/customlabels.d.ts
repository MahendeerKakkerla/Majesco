declare module "@salesforce/label/c.Candidate_Name" {
    var Candidate_Name: string;
    export default Candidate_Name;
}
declare module "@salesforce/label/c.Candidate_Score" {
    var Candidate_Score: string;
    export default Candidate_Score;
}
declare module "@salesforce/label/c.Current_Candidate" {
    var Current_Candidate: string;
    export default Current_Candidate;
}